/**
 * The cut line is a cliff, not a curve.
 *
 * Measured in the live season (tools/pursecheck.ts): make-cut runs
 *   72 57 60 60 · 36 38 44 42 42 · 19 18 18 15 24
 * Those are not three phases of a squeeze, they are two cliffs. The line moves
 * by ONE stroke at event 5 and make-cut drops 24 points; it moves one more at
 * event 10 and drops another 23. A four-hole score is an integer concentrated
 * on about four values, so a stroke-wide step is a probability step, and
 * "gradually par won't be good enough" cannot be built out of it.
 *
 * The fix is the one real golf already uses: cut to a NUMBER OF PLAYERS, not to
 * a score. Top N and ties. N is continuous where a stroke line is not, the
 * leaderboard already on screen becomes the thing deciding your week, and the
 * field no longer needs the fieldEdge fudge that dragged its median onto the
 * line every week.
 *
 * This measures where you actually stand after four holes, per event, so the
 * N curve can be read off the distribution instead of guessed.
 *
 * Run: npx tsx src/tools/cutcheck.ts
 */
import { PINE_HOLLOW } from '../content/courses/pinehollow'
import { HAND_SIZE, PUNCH_OUT, REDRAW_COST, STARTING_DECK, CARD } from '../content/cards'
import { SEASON } from '../content/season'
import { buildCone } from '../sim/effects'
import { chooseShot, type Policy } from './policy'
import { resolveShot, dropPoint } from '../sim/resolve/shot'
import { resolvePutting, sinkCost, baseputts } from '../sim/resolve/putt'
import { makeField, advanceField, standings, yourPlace } from '../sim/resolve/field'
import { surfaceAt, toPin } from '../sim/geometry'
import { seedBank, type RngBank } from '../sim/rng'
import { draw } from '../sim/deck'
import type { Boost, HoleSpec, Point, Surface } from '../sim/types'

interface Ctx { bank: RngBank; deck: string[]; discard: string[]; focus: number }

function playHole(hole: HoleSpec, ctx: Ctx, boosts: Boost[], policy: Policy) {
  const res = draw(HAND_SIZE, ctx.deck, ctx.discard, ctx.bank.draw)
  ctx.deck = res.deck; ctx.discard = res.discard
  ctx.bank = { ...ctx.bank, draw: res.rng }
  let hand = res.hand
  let ball: Point = { down: 0, side: 0 }
  let lie: Surface = 'tee'
  let strokes = 0
  let redrawn = false

  for (let i = 0; i < 14; i++) {
    if (lie === 'green') {
      const feet = Math.max(1, Math.round(toPin(hole, ball) * 3))
      const cost = sinkCost(feet)
      const worth = cost !== null && cost > 0 && cost <= ctx.focus
        && baseputts(feet) > 1 && strokes + 1 <= hole.par - 1
      if (worth && cost) ctx.focus -= cost
      strokes += resolvePutting(feet, worth).strokes
      break
    }
    if (!redrawn && ctx.focus >= REDRAW_COST) {
      const reach = Math.max(...hand.map(id => CARD[id])
        .filter(c => !!c && c.kind === 'shot')
        .map(c => (c as { carry: number }).carry), PUNCH_OUT.carry)
      if (reach * Math.max(1, hole.par - 2) < toPin(hole, ball) * 0.85) {
        ctx.focus -= REDRAW_COST
        ctx.discard.push(...hand)
        const rr = draw(HAND_SIZE, ctx.deck, ctx.discard, ctx.bank.draw)
        ctx.deck = rr.deck; ctx.discard = rr.discard
        ctx.bank = { ...ctx.bank, draw: rr.rng }
        hand = rr.hand; redrawn = true
      }
    }
    const { shot, techs, aim } = chooseShot(hole, ball, lie, hand, policy, ctx.focus, boosts)
    ctx.focus -= techs.reduce((n, t) => n + t.focus, 0)
    const b = buildCone({ shot, techniques: techs, aim }, lie, toPin(hole, ball), boosts)
    const [out, nb] = resolveShot(hole, ball, b.cone, b.ctx, ctx.bank.shot)
    ctx.bank = { ...ctx.bank, shot: nb }
    strokes += 1 + out.penalty
    if (out.penalty > 0) { ball = dropPoint(out.landing); lie = surfaceAt(hole, ball) }
    else { ball = out.landing; lie = out.surface }
    if (strokes >= 10) { strokes = 10; break }
  }
  ctx.discard.push(...hand)
  ctx.focus = Math.min(5, ctx.focus + 1)
  return strokes
}

const N = Number(process.env.N ?? 400)
/** Equipment bought over a season, as a cone multiplier. 1.0 = buys nothing. */
const KIT = Number(process.env.KIT ?? 1)

/** Your place after four holes, for every event of every season. */
function seasonPlaces(seed: number, policy: Policy): number[] {
  const ctx: Ctx = { bank: seedBank(seed), deck: [...STARTING_DECK], discard: [], focus: 5 }
  const out: number[] = []
  SEASON.forEach((ev, ei) => {
    // equipment accumulates through the season
    const kit = Math.pow(KIT, ei / (SEASON.length - 1))
    const boosts: Boost[] = [{
      id: '_s', name: '', icon: '', blurb: '', price: 0, spreadScale: ev.sharpness * kit,
    }]
    ctx.focus = 5
    let [field, fr] = makeField(ctx.bank.field)
    ctx.bank = { ...ctx.bank, field: fr }
    let rel = 0
    // FOUR holes — the cut is judged here. No fieldEdge: the field is static.
    PINE_HOLLOW.slice(0, 4).forEach((hole, i) => {
      rel += playHole(hole, ctx, boosts, policy) - hole.par
      const [f2, r2] = advanceField(field, i, ctx.bank.field)
      field = f2; ctx.bank = { ...ctx.bank, field: r2 }
    })
    // play the rest so the deck cycles the way a real event would
    PINE_HOLLOW.slice(4).forEach((hole, i) => {
      playHole(hole, ctx, boosts, policy)
      const [f2, r2] = advanceField(field, i + 4, ctx.bank.field)
      field = f2; ctx.bank = { ...ctx.bank, field: r2 }
    })
    out.push(yourPlace(standings(field, rel, 4, false)))
  })
  return out
}

const pct = (v: number[], p: number) => [...v].sort((a, b) => a - b)[Math.floor(v.length * p)]!

for (const policy of ['safe', 'mixed', 'aggressive'] as Policy[]) {
  const seasons = Array.from({ length: N }, (_, i) => seasonPlaces(120_000 + i, policy))
  console.log(`\nWHERE YOU STAND AFTER FOUR HOLES · ${policy} · ${N} seasons · kit ×${KIT}`)
  console.log('  ev   p25   median   p75      make-cut if the line is top-…')
  console.log('       ' + '-'.repeat(78))
  for (let ev = 0; ev < SEASON.length; ev++) {
    const places = seasons.map(s => s[ev]!)
    const rate = (n: number) => (places.filter(p => p <= n).length / N * 100).toFixed(0).padStart(3)
    console.log(
      `  ${String(ev + 1).padStart(2)}   ${String(pct(places, .25)).padStart(3)}   ` +
      `${String(pct(places, .5)).padStart(6)}   ${String(pct(places, .75)).padStart(3)}   ` +
      `   45:${rate(45)}%  35:${rate(35)}%  25:${rate(25)}%  18:${rate(18)}%  12:${rate(12)}%  8:${rate(8)}%  5:${rate(5)}%`,
    )
  }
}
console.log()

/* ------------------------------------------------------------------ *
 * Candidate N curves, scored against the measured place distribution.
 * ------------------------------------------------------------------ */
const CURVES: { label: string; n: number[] }[] = [
  { label: 'linear 42→14', n: Array.from({ length: 14 }, (_, i) => Math.round(42 - i / 13 * 28)) },
  { label: 'linear 44→10', n: Array.from({ length: 14 }, (_, i) => Math.round(44 - i / 13 * 34)) },
  { label: 'eased  45→12', n: Array.from({ length: 14 }, (_, i) => Math.round(45 - Math.pow(i / 13, 1.35) * 33)) },
]

console.log('\nCANDIDATE CUT CURVES · make-cut per event · kit ×' + KIT)
for (const policy of ['safe', 'mixed', 'aggressive'] as Policy[]) {
  const seasons = Array.from({ length: N }, (_, i) => seasonPlaces(120_000 + i, policy))
  console.log(`\n  ${policy}`)
  for (const c of CURVES) {
    const rates = c.n.map((n, ev) => seasons.filter(s => s[ev]! <= n).length / N * 100)
    console.log(
      `    ${c.label.padEnd(13)} ` +
      rates.map(r => r.toFixed(0).padStart(3)).join(' ') +
      `   overall ${(rates.reduce((a, b) => a + b, 0) / 14).toFixed(0)}%`,
    )
  }
  console.log('    ' + ' '.repeat(13) + ' ' + CURVES[0]!.n.map(n => String(n).padStart(3)).join(' ') + '   ← top-N (linear 42→14)')
}
console.log()
